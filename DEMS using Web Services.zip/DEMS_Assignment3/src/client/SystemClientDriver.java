package client;

import java.io.IOException;


/**
 * @author Yogesh Nimbhorkar
 *
 */
public class SystemClientDriver {

	public static void main(String args[]) throws IOException {
		ClientImplementation client = new ClientImplementation();
			client.systemHome();
		

	}

}
